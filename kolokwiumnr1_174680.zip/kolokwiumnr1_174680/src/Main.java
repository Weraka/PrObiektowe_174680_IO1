import java.util.ArrayList;
public class Main {
    public static class Elf
    {
        private String imie;
        private int wiek;
        private String stanowisko;

        public Elf(String imie, int wiek, String stanowisko)
        {
            this.imie = imie;
            this.wiek = wiek;
            this.stanowisko = stanowisko;
        }
        public String getImie()
        {
            return imie;
        }
        public void setImie(String imie)
        {
            if(imie == null)
            {
                System.out.println("brak imienia");
            }
            else
            {
                this.imie = imie;
            }

        }
        public int getWiek()
        {
            return wiek;
        }
        public void setWiek(int wiek)
        {
            if(wiek<0)
            {
                System.out.println("Nieprawidlowa wartosc");
            }
            this.wiek = wiek;
        }
        public String getStanowisko()
        {
            return imie;
        }
        public void setStanowisko(String stanowisko)
        {
            if(stanowisko == null)
            {
                System.out.println("brak stanowiska");
            }
            else
            {
                this.stanowisko = stanowisko;
            }
        }
        @Override
        public String toString()
        {
            return "Cześć, nazywam się " + imie + " , mam " + wiek + " , a moje stanowisko pracy to " + stanowisko;
        }

    }
    public static class Fabryka
    {
        private ArrayList<Elf> listaElfow;
        private double dlGeo;
        private double szGeo;

        public Fabryka(double dlGeo, double szGeo)
        {
            this.listaElfow= new ArrayList<>();
            this.dlGeo = dlGeo;
            this.szGeo = szGeo;
        }
        public ArrayList<Elf> getListaElfow()
        {
            if(listaElfow.isEmpty())
            {
                return null;
            }
            else
            {
                return listaElfow;
            }
        }
        public void setListaElfow(ArrayList<Elf> listaElfow)
        {
            this.listaElfow = listaElfow;
        }
        public double getDlGeo()
        {
            return dlGeo;
        }
        public void setDlGeo(double dlGeo)
        {
            if(dlGeo>-180&&dlGeo<180)
            {
                this.dlGeo = dlGeo;
            }
            else
            {
                System.out.println("Nieprawidlowa wartosc");
            }
        }
        public double getSzGeo()
        {
            return dlGeo;
        }
        public void setSzGeo(double szGeo)
        {
            if(szGeo>-90&&szGeo<90)
            {
                this.szGeo = szGeo;
            }
            else
            {
                System.out.println("Nieprawidlowa wartosc");
            }
        }
        @Override
        public String toString()
        {
            return listaElfow + " Dlugosc geo: " + dlGeo + " Szerokosc geo: " + szGeo;
        }
        public void dodajPracownika(Elf nowyPracownik)
        {
            listaElfow.add(nowyPracownik);
        }
        public void usunPracownika(Elf pracownik)
        {
            listaElfow.remove(pracownik);
        }
        public Elf najstarszyPracownik()
        {
            Elf najstarszy = listaElfow.getFirst();

            for(int i=1; i< listaElfow.size();i++)
            {
                if(najstarszy.wiek < listaElfow.get(i).wiek)
                {
                    najstarszy = listaElfow.get(i);
                }
            }
            return najstarszy;
        }
    }
    public static class Renifer
    {
        private String imie;
        private int predkosc;

        public Renifer(String imie, int predkosc)
        {
            this.imie = imie;
            this.predkosc = predkosc;
        }
        public String getImie()
        {
            return imie;
        }
        public void setImie(String imie)
        {
            if(imie == null)
            {
                System.out.println("Brak imienia");
            }
            else
            {
                this.imie = imie;
            }
        }
        public int getPredkosc()
        {
            return predkosc;
        }
        public void setPredkosc(int predkosc)
        {
            if(predkosc<=0)
            {
                System.out.println("Nieprawidlowa predkosc");
            }
            else
            {
                this.predkosc = predkosc;
            }
        }
        @Override
        public String toString()
        {
            return imie + " " + predkosc;
        }
        
        public void nakarmRenifera()
        {
            predkosc+=5;
        }

    }
    public static class Sanie
    {
        private ArrayList<Renifer> listaReniferow;

        public Sanie()
        {
            this.listaReniferow = new ArrayList<>();
        }
        public ArrayList<Renifer> getListaReniferow()
        {
            if(listaReniferow.isEmpty())
            {
                return null;
            }
            else
            {
                return listaReniferow;
            }
        }
        public void setListaReniferow(ArrayList<Renifer> listaReniferow)
        {
            this.listaReniferow = listaReniferow;
        }
        public void wyswietl()
        {
            System.out.println(listaReniferow);
        }
        public void dodajRenifera(Renifer nowy)
        {
            listaReniferow.add(nowy);
        }
        public void sumaPredkosci()
        {
            int suma = 0;
            for(int i=0;i<listaReniferow.size(); i++)
            {
                suma = suma + listaReniferow.get(i).predkosc;
            }
            System.out.println(suma);
        }
        public Renifer najwolniejszyRenifer()
        {
            Renifer najwoln = listaReniferow.getFirst();
            for(int i=0;i<listaReniferow.size();i++)
            {
                if(najwoln.predkosc > listaReniferow.get(i).predkosc)
                {
                    najwoln = listaReniferow.get(i);
                }
            }
            return najwoln;
        }
    }
    public static void main(String[] args)
    {
        Elf maciek = new Elf("Maciek", 14, "osoba sprzątająca stajnie");
        Elf zosia = new Elf("Zosia", 17, "osoba pakująca prezenty");
        System.out.println(maciek.toString());
        System.out.println(zosia.toString());
        Fabryka fabryka = new Fabryka(1234.32, 312.4);
        fabryka.dodajPracownika(maciek);
        fabryka.dodajPracownika(zosia);
        System.out.println(fabryka.najstarszyPracownik().imie);
        fabryka.usunPracownika(zosia);
        System.out.println(fabryka.najstarszyPracownik().imie);
        Renifer r1 = new Renifer("Rudolf",30);
        Renifer r2 = new Renifer("Rudek",20);
        System.out.println(r1.toString());
        r1.nakarmRenifera();
        r2.nakarmRenifera();
        System.out.println(r1.toString());
        Sanie sanie = new Sanie();
        sanie.dodajRenifera(r1);
        sanie.dodajRenifera(r2);
        sanie.wyswietl();
        System.out.println(sanie.najwolniejszyRenifer().imie);
        sanie.sumaPredkosci();

    }
}
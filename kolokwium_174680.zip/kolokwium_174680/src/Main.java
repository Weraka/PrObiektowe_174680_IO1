public class Main {



    public static void ciagArytmetycznyRodzajuM(int n, int m, int a1, int r)
    {
        double wynik = a1;
        for(int i = 0; i < n; i++)
        {
            System.out.println(wynik);
            wynik = wynik + Math.pow((n-1),m)*r;

        }

    }

    public static boolean czyCiagArytmetyczny(int[] tab)
    {
        for(int i = 1; i < tab.length; i++)
        {
            for(int j = 1; j <tab.length; j++)
            {
                if(tab[j]-tab[i] != tab[j-1]-tab[i-1])
                {
                    return false;
                }
            }
        }
        return true;
    }

    public static int podciag(int[] tab)
    {
        int suma = 0;
        for(int i = 1; i < tab.length; i++)
        {
            if(tab[i-1]<tab[i])
            {

                suma++;

            }

        }
        return suma;
    }

    public static int podciag(int[] tab, int r)
    {
        int suma = 1;
        for(int i = 1; i < tab.length; i++)
        {
            if(tab[i]-tab[i-1]==r)
            {
                suma++;

            }

        }
        return suma;
    }


    public static void sekwencjaCollatza(int n, int c)
    {
        int nowa = 0;

        for(int i=c;i<n+c;i++)
        {
            if(i%2!=0)
            {
                nowa = i*3 + 1;
                System.out.print(nowa+", ");

            }

            else
            {
                System.out.print(i+", ");
            }
        }
    }

    public static void minMaxSekwencjaCollatza(int n, int c)
    {

        int[] tab = new int[n];

            for(int i=c;i<n+c;i++)
            {
                if(i%2!=0)
                {
                    tab[i-c] = i*3 + 1;
                    System.out.print(tab[i-c]+", ");

                }

                if(i%2==0)
                {
                    tab[i-c] = i;
                    System.out.print(tab[i-c]+", ");

                }

            }
            int min = 0;
            int max = 0;
            for(int i=1;i<n;i++)
            {
                if(tab[i-1]<tab[i])
                {
                    min = tab[i-1];
                    max = tab[i];
                }

            }

            System.out.println("\n" + min);
            System.out.println(max);


    }


    public static void main(String[] args)
    {
        int[] tab = new int[7];
        tab[0] = 1;
        tab[1] = 2;
        tab[2] = 0;
        tab[3] = 3;
        tab[4] = 5;
        tab[5] = 1;
        tab[6] = 4;

        //System.out.print(czyCiagArytmetyczny(tab));

        //sekwencjaCollatza(16,2);
        //minMaxSekwencjaCollatza(16,2);
        //ciagArytmetycznyRodzajuM(4,1,1,2);
        System.out.println(podciag(tab));
    }
}